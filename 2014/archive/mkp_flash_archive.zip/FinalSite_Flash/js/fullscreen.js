window.moveTo(0,0);
window.resizeTo(window.screen.availWidth,window.screen.availHeight)

/*fixed size window + position center

iWidth = "1020";
iHeight = "600";

window.resizeTo("1020","650");
window.moveTo((window.screen.availWidth - 1020)/2,(window.screen.availHeight - 650)/2); 
*/